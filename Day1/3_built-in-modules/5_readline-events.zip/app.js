const readline = require('readline');
const fs = require('fs');

const rl = readline.createInterface({
    input: process.stdin,           // ReadStream
    output: process.stdout          // WriteStream
});

var file = fs.createWriteStream('./output.txt');

console.log("Waiting for input (Press Ctrl + c to exit)...\n\n");

rl.on('line', (input) => {
    file.write(input + "\n");
});

rl.on('SIGINT', () => {
    rl.question('Are you sure you want to exit? ', (answer) => {
        if (answer.match(/^y(es)?$/i)) {
            rl.close();
            file.end();
        }
    });
});