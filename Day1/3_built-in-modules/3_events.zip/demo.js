var events = require('events');
var eEmitter = new events.EventEmitter();

// Subscribe
eEmitter.addListener('test', () => {
    console.log("Listener Called....");
})

eEmitter.emit('test');          // Publish