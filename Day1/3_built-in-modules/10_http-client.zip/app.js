const https = require('https');
const fs = require('fs');

const url = "https://jsonplaceholder.typicode.com/posts";

var options = {
    method: 'GET',
}

const request = https.request(url, options, (res) => {
    if (res.statusCode !== 200) {
        console.log("Request not completed...");
        res.resume();
        return;
    }

    let data = '';

    res.on('data', (chunk) => {
        // console.log("Chunk Recieved...");
        data += chunk;
    });

    res.on('close', () => {
        console.log("All data recieved...");
        // console.log(JSON.parse(data).length);
        fs.writeFileSync('posts.json', data);
    });
});

request.end();