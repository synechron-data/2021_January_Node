const Account = require('./Account');
const SMS = require('./SMS');
const Email = require('./Email');

let a1 = new Account(1, 1000, 6);
let sms = new SMS();
let email = new Email();

// Code to Display message on the console
a1.on('depositSuccess', (balance) => {
    console.log("\nAmount Deposited Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    console.log("\nAmount withdrawn Successfully...");
    console.log(`New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    console.log("\nAmount withdraw Failed...");
    console.log(`New Account Balance is: INR ${balance}`);
});

// Code to send SMS
a1.on('depositSuccess', (balance) => {
    sms.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    sms.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    sms.send(`Amount Withdraw Failed - Account Balance is: INR ${balance}`);
});

// Code to send Email
a1.on('depositSuccess', (balance) => {
    email.send(`Amount Deposited - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawSuccess', (balance) => {
    email.send(`Amount Withdrawn - New Account Balance is: INR ${balance}`);
});

a1.on('withdrawFailure', (balance) => {
    email.send(`Amount Withdraw Failed - Account Balance is: INR ${balance}`);
});

a1.deposit(1000);
a1.withdraw(2000);
a1.withdraw(1000);