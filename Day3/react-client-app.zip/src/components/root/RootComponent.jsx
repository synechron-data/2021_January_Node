import React from 'react';
import userAPIClient from '../../services/users.service';
import DataTable from '../common/DataTable';

class RootComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = { users: [] };
        this.loadData = this.loadData.bind(this);
    }

    loadData() {
        userAPIClient.getAllUsers().then((data) => {
            this.setState({ users: [...data] });
        });
    }

    render() {
        return (
            <div className="container">
                <h2 className="text-info">React Application</h2>

                <button onClick={this.loadData} className="btn btn-primary">Load Data</button>
                <DataTable items={this.state.users}>
                    <h4 className="text-primary text-uppercase font-weight-bold">Users Table</h4>
                </DataTable>
            </div>
        );
    }
}

export default RootComponent;